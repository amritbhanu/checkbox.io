install mongodb
mkdir /data/db
give permissions to user for /data/db folder
install
    "marked": "0.3.6",
    "jade": "^1.9.2",
    "json5": "^0.4.0",
    "mongodb": "*",
    "emailjs":"*",
    "validator":"*",
    "underscore": "^1.7.0"
