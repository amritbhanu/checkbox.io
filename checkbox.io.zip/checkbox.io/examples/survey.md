{NumberQuestions:true}
-----------
^ Start with header.

### Multiple Choice Question (Check all that apply)

* Choice A
* Choice B
* Choice C

### Single Choice Question

A *description* for question.

1. Choice
2. Choice
3. Choice

### Ranking/Rating Table

Columns n+1 can be empty.  [Use github flavored markdown for table formatting](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet#wiki-tables)

| Column | Rating        | Rating|
| -------|:-------------:|:-----:|
| Choice | 1             | 2     |
| Choice | 1             | 2     |
| Choice | 1             | 2     |
| Choice | 1             | 2     |
| Choice | 1             | 2     |

-------------------------------------

### Text multiple line answer
Please go into **great** detail.

> {rows:5}

### Text single line answer

You can enter in `{rows:1}` or leave blank.

> {}

